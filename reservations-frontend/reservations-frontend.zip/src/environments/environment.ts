export const environment = {
  redirectUrl: "http://localhost:4200/",
  production: false,
  apiUrl: 'http://localhost:8080/reservations',
};
