export const environment = {
  apiUrl: "",
  redirectUrl: "http://localhost:4200/",
  production: false,
};
