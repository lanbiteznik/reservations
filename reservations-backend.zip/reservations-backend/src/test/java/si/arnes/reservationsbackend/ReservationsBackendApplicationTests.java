package si.arnes.reservationsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
