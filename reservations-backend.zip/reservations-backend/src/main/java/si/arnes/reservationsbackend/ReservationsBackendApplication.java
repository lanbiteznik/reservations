package si.arnes.reservationsbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservationsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservationsBackendApplication.class, args);
	}
}

